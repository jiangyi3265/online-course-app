const n="/assets/login-banner-ClMzfOaE.png";export{n as _};
